package exercise1;

import java.util.Scanner;

public class Exercise1Solution2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Please enter the first number: ");
        int number1 = scanner.nextInt();

        System.out.print("Please enter the second number: ");
        int number2 = scanner.nextInt();

        System.out.print("Please enter the operator (+ - * /): ");
        String operator = scanner.next();

        int result = 0;
        switch (operator) {
            case "+":
                result = number1 + number2;
                System.out.println("Result = " + result);
                break;
            case "-":
                result = number1 - number2;
                System.out.println("Result = " + result);
                break;
            case "*":
                result = number1 * number2;
                System.out.println("Result = " + result);
                break;
            case "/":
                result = number1 / number2;
                System.out.println("Result = " + result); // Too much repetitive code? See solution 3
                break;
            default:
                System.out.println("Invalid operator");
                break;
        }
    }
}
