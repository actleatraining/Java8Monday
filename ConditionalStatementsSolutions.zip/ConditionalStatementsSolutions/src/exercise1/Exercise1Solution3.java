package exercise1;

import java.util.Scanner;

public class Exercise1Solution3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Please enter the first number: ");
        int number1 = scanner.nextInt();

        System.out.print("Please enter the second number: ");
        int number2 = scanner.nextInt();

        System.out.print("Please enter the operator (+ - * /): ");
        String operator = scanner.next();

        int result = 0;
        boolean invalidOperator = false;
        switch (operator) {
            case "+":
                result = number1 + number2;
                break;
            case "-":
                result = number1 - number2;
                break;
            case "*":
                result = number1 * number2;
                break;
            case "/":
                result = number1 / number2;
                break;
            default:
                invalidOperator = true;
        }

        if (invalidOperator) { // using a flag to know what happened in the switch statement
            System.out.println("Invalid operator");
        }
        else {
            System.out.println("Result = " + result);
        }
    }
}
