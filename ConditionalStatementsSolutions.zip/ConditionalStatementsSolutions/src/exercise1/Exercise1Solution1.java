package exercise1;

import java.util.Scanner;

public class Exercise1Solution1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Please enter the first number: ");
        int number1 = scanner.nextInt();

        System.out.print("Please enter the second number: ");
        int number2 = scanner.nextInt();

        System.out.print("Please enter the operator (+ - * /): ");
        String operator = scanner.next();

        int result = 0;
        if (operator.equals("+")) {
            result = number1 + number2;
            System.out.println("Result = " + result);
        }
        else if (operator.equals("-")) {
            result = number1 - number2;
            System.out.println("Result = " + result);
        }
        else if (operator.equals("*")) {
            result = number1 * number2;
            System.out.println("Result = " + result);
        }
        else if (operator.equals("/")) {
            result = number1 / number2;
            System.out.println("Result = " + result);
        }
        else {
            System.out.println("Invalid operator");
        }
    }
}
