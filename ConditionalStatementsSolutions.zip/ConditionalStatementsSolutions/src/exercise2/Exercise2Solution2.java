package exercise2;

public class Exercise2Solution2 {

    public static void main(String[] args) {
        int age = 7;
        boolean member = false;

        // Nested if/else statements to combine age and membership status
        if (age < 5) {
            System.out.println("Ticket price: free");
        }
        else if (age <= 10) {
            if (member) {
                System.out.println("Ticket price: 4 euros");
            }
            else {
                System.out.println("Ticket price: 6 euros");
            }
        }
        else if (age < 18) {
            if (member) {
                System.out.println("Ticket price: 8 euros");
            }
            else {
                System.out.println("Ticket price: 10 euros");
            }
        }
        else {
            if (member) {
                System.out.println("Ticket price: 12 euros");
            }
            else {
                System.out.println("Ticket price: 14 euros");
            }
        }
    }
}
