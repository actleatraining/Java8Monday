public class Demo1 {
    public static void main(String[] args) {

        System.out.println("println:");
        // println adds a new line character to the end of the line
        System.out.println("Hello World!");
        System.out.println("Hello World!");

        System.out.println("print:");
        // print doesn't add a new line character to the end of the line
        System.out.print("Hello World!");
        System.out.print("Hello World!");

        // just creating a new line
        System.out.println();
        System.out.println("format:");

        String arg1 = "World";
        double arg2 = 5.755;
        double arg3 = 176.3;

        // format uses placeholders and replaces them with arguments
        System.out.format("Hello %s!", arg1);
        System.out.println(); // creates a new line since format doesn't do that



        // Stretch tasks - extra information about format if you are interested!

        System.out.format("Hello %s!%n", arg1); // %n can be used to create a new line character

        System.out.format("Hello %S!%n", arg1); // using %S instead of %s will change to uppercase

        System.out.format("%s%n", arg2); // %s will work on numbers since they are automatically converted to String

        System.out.format("%f%n", arg2); // but the correct way is using %d for integer numbers and %f for floating point numbers

        // when using %f the number of digits after the decimal point can be specified
        System.out.format("%.2f%n", arg2); // .2 means two decimal digits

        // when using %f also the number of characters used for displaying the number can be specified - great for aligning numbers to the rigth
        System.out.format("%10.2f%n", arg2); // 10.2 means use 10 characters and have two decimal digits
        System.out.format("%10.2f%n", arg3); // same alignment despite other number of digits
    }
}