import java.util.Scanner;

public class Demo2 {
    public static void main(String[] args) {

        // Creating a Scanner object that works with System.in (the standard output stream, meaning the console):
        Scanner scanner = new Scanner(System.in);

        // Now we can use the Scanner object to read input from the console
        System.out.println("Please enter some text (try many words)");
        String line = scanner.nextLine(); // reads and returns the entire input into one String
        System.out.println(line);

        System.out.println("Please enter some text (try many words or only one word)");
        String word = scanner.next(); // reads the entire input, but returns only the first word
        System.out.println(word);

        System.out.println("If only one word was entered before now is a chance to enter another one!");
        String word2 = scanner.next(); // if more than one word was read before then the Scanner continues working with the old input and returns the second word withot asking the user for more input
        System.out.println(word2);

        scanner.nextLine(); // this clears the Scanner so that it will always ask the user for new input next time

        System.out.println("Please enter an integer number!");
        int number = scanner.nextInt();
        System.out.println(number);
    }
}