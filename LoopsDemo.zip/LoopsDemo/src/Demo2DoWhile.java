import java.util.Scanner;

public class Demo2DoWhile {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int answer = 0;

        do {
            System.out.println("What is 3 + 4?");
            answer = scanner.nextInt();
        }
        while (answer != 7);

        System.out.println("Correct answer!");
    }
}