import java.util.Scanner;

public class Demo3For {
    public static void main(String[] args) {

        System.out.println("Loop 1:");

        for (int i = 0; i < 3; i++) {
            System.out.println("Index: " + i);
        }

        System.out.println();
        System.out.println("Loop 2:");

        for (int i = 3; i > 0; i--) {
            System.out.println("Index: " + i);
        }

        System.out.println();
        System.out.println("Loop 3:");

        for (int i = 0; i < 3; i++) {
            System.out.println("Index: " + (3-i));
        }

        System.out.println();
        System.out.println("Loop 4:");

        for (int i = 0; i < 7; i+=3) {
            System.out.println("Index: " + i);
        }

        System.out.println();
        System.out.println("Loop 5:");

        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) {
                System.out.println(i + " is even");
            }
            else {
                System.out.println(i + " is odd");
            }
        }
    }
}