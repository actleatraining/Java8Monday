public class Demo5NestedLoops {
    public static void main(String[] args) {

        int number = 5;

        System.out.println("Not a nested loop:");

        for (int i = 0; i < number; i++) {
            System.out.println(i+1);
        }

        System.out.println();
        System.out.println("Nested loop 1:");

        for (int i = 0; i < number; i++) {
            for (int j = 0; j < number; j++) {
                System.out.println(i+1);
            }
        }

        System.out.println();
        System.out.println("Nested loop 2:");

        for (int i = 0; i < number; i++) {
            for (int j = 0; j < number; j++) {
                System.out.print(i+1);
            }
            System.out.println();
        }
    }
}