import java.util.Scanner;

public class Demo1IfElse {
    public static void main(String[] args) {

        System.out.println("What is 3 + 4?");
        Scanner scanner = new Scanner(System.in);
        int answer = scanner.nextInt();

        if (answer != 7) {
            System.out.println("Sorry, wrong answer, try again!");
            answer = scanner.nextInt();
        }
        else {
            System.out.println("Correct answer!");
        }

        // but what if it's incorrect again?
        if (answer != 7) {
            System.out.println("Sorry, wrong answer, try again!");
            answer = scanner.nextInt();
        }
        else {
            System.out.println("Correct answer!");
        }

        // but what if it's incorrect again... can't repeat the if statement manually like this to cover an infinite number of incorrect answers


    }
}