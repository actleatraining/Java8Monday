import java.util.Scanner;

public class Demo1While {
    public static void main(String[] args) {

        System.out.println("What is 3 + 4?");
        Scanner scanner = new Scanner(System.in);
        int answer = scanner.nextInt();

        while (answer != 7) {
            System.out.println("Sorry, wrong answer, try again!");
            answer = scanner.nextInt();
        }

        System.out.println("Correct answer!");
    }
}