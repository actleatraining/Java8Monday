import java.util.Scanner;

public class Exercise1Task3 {
    public static void main(String[] args) {
        System.out.println("Please enter a number!");
        Scanner scanner = new Scanner(System.in);
        int number1 = scanner.nextInt();
        System.out.println("Please enter another number!");
        int number2 = scanner.nextInt();
        int sum = number1 + number2;
        System.out.println("The sum of " + number1 + " and " + number2 + " is " + sum);
    }
}