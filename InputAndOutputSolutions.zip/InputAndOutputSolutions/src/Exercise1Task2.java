import java.util.Scanner;

public class Exercise1Task2 {
    public static void main(String[] args) {
        System.out.println("Please enter a number!");
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        System.out.println("If you double the number " + number + " you will get " + number*2);
    }
}